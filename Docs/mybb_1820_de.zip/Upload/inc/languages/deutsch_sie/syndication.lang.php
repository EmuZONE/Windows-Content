<?php
/**
 * German language pack for MyBB 1.8 (formal)
 * Deutsches Sprachpaket für MyBB 1.8 "formell" (Sie)
 * (c) 2005-2014 MyBBoard.de
 * 
 * Author/Autor: http://www.mybboard.de/
 * License/Lizenz: GNU Lesser General Public License, Version 3
 */

$l['all_forums'] = "Alle Foren";
$l['forum'] = "Forum:";
$l['posted_by'] = "Geschrieben von:";
$l['on'] = "am";
$l['portal'] = "Portal";
