<?php
/**
 * German language pack for MyBB 1.8 (formal)
 * Deutsches Sprachpaket für MyBB 1.8 "formell" (Sie)
 * (c) 2005-2014 MyBBoard.de
 * 
 * Author/Autor: http://www.mybboard.de/
 * License/Lizenz: GNU Lesser General Public License, Version 3
 */
 
$l['templates_and_style'] = "Templates &amp; Style";

$l['themes'] = "Themes";
$l['templates'] = "Templates";

$l['can_manage_themes'] = "Kann Themes verwalten?";
$l['can_manage_templates'] = "Kann Templates verwalten?";
